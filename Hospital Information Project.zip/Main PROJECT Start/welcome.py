from tkinter import *
import login
from PIL import Image,ImageTk
import doctor_login

class Welcome:
    def __init__(self):
        self.root = Tk()
        #If tkinter doent load image than use Toplevel() instead of Tk()
        self.root.title("Doctor Navigation | Doctor Patient Management")
        self.fullwidth = self.root.winfo_screenwidth()
        self.fullheight = self.root.winfo_screenheight()
        self.width = int((self.fullwidth - 900) / 2)
        self.height = int((self.fullheight - 600) / 2)-50
        s = "900x600+" + str(self.width) + "+" + str(self.height)
        self.root.resizable(height=False, width=False)

        self.root.geometry(s)
    def frame(self):
        self.fra = Frame(self.root, bg='white')
        self.fra.place(x=0, y=0, width="900", height="600")

        img = ImageTk.PhotoImage(Image.open("images/img_login.webp"))
        self.img = Label(self.fra,image=img)
        self.img.place(x=0,y=0,width="900",height="600")

        self.lab=Label(self.fra,text="WELCOME",anchor=E,bg="light sky blue",fg="black")
        self.lab.place(x=200,y=50, width="250", height="45")
        self.lab.config(font=("calibri",40,"bold"))
        self.btn=Button(self.fra,text="DOCTOR",bg="sky blue",fg="black",font="30",command=self.doctor)
        self.btn.place(x=120,y=400,width="200",height="50")
        self.btn.config(font=("Calibri",20,"bold"))
        self.btn = Button(self.fra, text="ADMIN", bg="sky blue",fg="black",font="30",command=self.recept)
        self.btn.place(x=350, y=400, width="200",height="50")
        self.btn.config(font=("Calibri",20,"bold"))
        self.root.mainloop()

    def doctor(self):
        self.root.destroy()
        obj1 = doctor_login.AdminLogin()
        obj1.loginFrame()
    def recept(self):
        self.root.destroy()
        obj1 = login.AdminLogin()
        obj1.loginFrame()
        
if __name__=="__main__":
    obj=Welcome()
    obj.frame()
